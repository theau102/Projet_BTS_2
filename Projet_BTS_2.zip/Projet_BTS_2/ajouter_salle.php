<?php
 session_start(); 
 ?>

<html>


	<head>
		
	</head>

	<body>

		</form>
		<link rel="stylesheet" type="text/css" href="css/index.css" />
    
    <form action="add_salle.php" method="POST">
        <p>nom de la salle <input type="text" name="nom_salle" /></p>
        <p><input type="submit" value="OK"></p>
    </form>


	</body>

</html>