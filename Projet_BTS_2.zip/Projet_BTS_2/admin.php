<?php
session_start(); 


?>
<!-- incorporation du css -->
<link rel="stylesheet" type="text/css" href="css/admin.css" />

<!-- boutton de deconnexion -->
<a href="deconnexion.php">deconnexion</a>

<!-- boutton de modification de salle -->
</br><a href="modification_salle.php">modifier une salle</a>

<!-- boutton pour voir le planning -->
</br><a href="creneau_admin.php">Voir le planning</a>

